import React, {Component} from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import '../assets/Paises.css'

class Paises extends Component
{
    
    render()
    {
          return(
              <div className="row">
                <div className = "card divCarta" >

                    <div className="card-head-centered">
                        <div className="imageSpace">
                            <h5 className="texto">Flag image here</h5>
                        </div>
                    </div>
                    <div className="card-body">
                        <h5>Name: {this.props.name}</h5>
                    </div>
                    <div className="card-footer">
                        <h2>Region: {this.props.region}</h2>
                        <h4>Subregion: {this.props.subregion}</h4>

                    </div>
                    
                </div>
            </div>

        );
    }
    
}

 

  
export default Paises