import React, {Component} from 'react'
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import Paises from './componentes/Paises.js'
import axios from 'axios';

class App extends Component
{
  state = {
    persons: []
  }

  componentDidMount() {
    axios.get(`https://restcountries.eu/rest/v2/all`)
      .then(res => {
        const persons = res.data;
        this.setState({ persons });
      })
  }
  render()
  {
    return (
      <div className="App row">
      {     
        this.state.persons.map(person => <Paises key={person.alpha3Code} name = {person.name} region = {person.region} subregion = {person.subregion}/>)
      }
      </div>
    );
  }
}

export default App;
